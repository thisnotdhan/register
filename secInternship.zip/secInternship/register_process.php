<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "interns_management";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST["name"];
    $gender = $_POST["gender"];
    $age = $_POST["age"];
    $birthday = $_POST["birthday"];
    $contact_number = $_POST["contact-number"];
    $school = $_POST["school"];
    $course = $_POST["course"];
    $department = $_POST["department"];
    $hours_required = $_POST["hours-required"];
    $emergency_contact = $_POST["emergency-contact"];

    // Prepare and bind SQL statement
    $stmt = $conn->prepare("INSERT INTO interns_profile (name, gender, age, birthday, contact_number, school, course, department, hours_required, emergency_contact) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssisssssis", $name, $gender, $age, $birthday, $contact_number, $school, $course, $department, $hours_required, $emergency_contact);

    // Execute the SQL statement
    if ($stmt->execute()) {
        // Display success alert message and redirect to internslogin.php
        echo '<script>alert("Registration successful!"); window.location.href = "internslogin.php";</script>';
    } else {
        echo '<script>alert("Error: ' . $stmt->error . '");</script>';
    }

    // Close statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
