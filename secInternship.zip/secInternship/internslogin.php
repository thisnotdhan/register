<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" 
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Login</title>
     <link rel="stylesheet" href="login.css">
<style>
   body {
    .card {
        background-color: #fefefe;
    }
    background: url(https://scontent.fmnl4-4.fna.fbcdn.net/v/t1.15752-9/367498524_819818559607764_1678023911988781221_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=ae9488&_nc_eui2=AeHTH5DYayfv0h_amNzIrzj5CYVrM8fr4OkJhWszx-vg6QLvZQGrx6AWJGsqD2WVuQ2gqQtqpFOCa6aL0SM1KQn_&_nc_ohc=LM_8VqJul3kAX9sQPMY&_nc_ht=scontent.fmnl4-4.fna&oh=03_AdSp63gJ6MhDTcMzqt2Mplfrh3sHngFJ5B3nfQ3Q5htw5A&oe=6512BC08);
    background-repeat: no repeat;
    background-size: cover;
   }
</style>


</head>
<body>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>Login</h2>
            </div>
            <div class="card-body">
                <form action="login_process.php" method="post">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Login</button>
                </form>
                <div class="text-center mt-3">
                    <a href="#" class="forgot-password">Forgot Password?</a>
                </div>
            </div>
            <div class="card-footer text-center">
                <p class="mb-0">Don't have an account?</p>
                <button onclick="location.href='internsregister.php'" class="btn btn-outline-primary">Register</button>
            </div>
        </div>
    </div>
</body>
</html>
